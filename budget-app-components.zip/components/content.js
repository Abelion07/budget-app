export function Main() {
  const main = document.createElement("main");
  main.className = "main";
  main.innerHTML = "<section class='content'></section>";
  return main;
}
