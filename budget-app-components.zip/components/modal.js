export function TransactionModal() {
  const div = document.createElement("div");
  div.className = "modal";
  return div;
}
