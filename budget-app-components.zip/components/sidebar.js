export function Sidebar() {
  const aside = document.createElement("aside");
  aside.className = "sidebar";
  aside.innerHTML = `<div class="brand"><div class="logo">₿</div><div><div class="brand-title">Budget</div><div class="brand-sub">követő</div></div></div>`;
  return aside;
}
